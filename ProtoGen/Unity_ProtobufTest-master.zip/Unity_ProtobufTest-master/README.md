# Unity_ProtobufTest
在Unity中使用protobuf

Unity工程在UnityProject文件夹中

Protobuf相关文件在ProtobufFile文件夹中

具体说明链接 http://www.jianshu.com/p/b135676dbe8d
